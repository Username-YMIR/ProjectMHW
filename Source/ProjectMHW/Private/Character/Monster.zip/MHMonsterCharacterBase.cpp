// 제작자 : 손승우
// 제작일 : 2026-03-04
// 수정자 : 허혁
// 수정일 : 2026-03-06


#include "Character/Monster/MHMonsterCharacterBase.h"
#include "AbilitySystemComponent.h"
#include "GameplayEffect.h"
#include "Character/Monster/Attribute/MHMonsterAttributeSet.h"
#include "Components/CapsuleComponent.h"
#include "DataAsset/MHMonsterDataAsset.h"
#include "Kismet/GameplayStatics.h"

DEFINE_LOG_CATEGORY(MonsterCharacter)

AMHMonsterCharacterBase::AMHMonsterCharacterBase()
{
    MonsterAttributes  = CreateDefaultSubobject<UMHMonsterAttributeSet>(TEXT("MonsterAttributeSet"));
    AttributeSet = MonsterAttributes;
}

void AMHMonsterCharacterBase::BeginPlay()
{
    Super::BeginPlay();
    
    InitMonsterGAS();

    
    
    
}

void AMHMonsterCharacterBase::CheckRoar()
{
    //broarcheck 
    if (!bInCombat)
    {
        UE_LOG(MonsterCharacter, Warning, TEXT("CheckRoar | not in combat"));
        return;
    }
    
    //bCanRoar
    if (bHasRoared)
    {
        UE_LOG(MonsterCharacter , Warning , TEXT(" : MonsterCharacter Base CheckRoar !bCanRoar"));
        return;
    }
    //RoarMontage
    if (!RoarMontage)
    {
        UE_LOG(MonsterCharacter , Warning , TEXT(" : MonsterCharacter Base CheckRoar !RoarMontage"));
        return;
    }
    
    ACharacter* PlayerCharacter = UGameplayStatics::GetPlayerCharacter(this , 0);
    //PlayerCharacter
    if (!PlayerCharacter)
    {
        UE_LOG(MonsterCharacter , Warning , TEXT(" : MonsterCharacter Base CheckRoar !PlayerCharacter"));
        return;
    }
    
    if (!CanTriggerRoarToTarget(PlayerCharacter))
    {
        UE_LOG(MonsterCharacter, Warning, TEXT("CheckRoar | CanTriggerRoarToTarget false"));
        return;
    }
    
    // 몽타주 재생 
    if (USkeletalMeshComponent* MeshComp = GetMesh())
    {
        if (UAnimInstance* Anim = MeshComp->GetAnimInstance())
        {
            // 중복체크
            if (!Anim->Montage_IsPlaying(RoarMontage))
            {
                                // 몽타주 재생 몽타주종류 , 재생 속도
                const float PlayedLen = Anim->Montage_Play(RoarMontage, 1.0f);

                if (PlayedLen > 0.f)
                {
                    bHasRoared = true;
                    GetWorldTimerManager().ClearTimer(RoarCheckTimer);
                }
            }
            
        }
    }
    
}

void AMHMonsterCharacterBase::StartRoarCheck()
{
    if (bHasRoared)
    {
        return;
    }
    
    if (!GetWorldTimerManager().IsTimerActive(RoarCheckTimer))
    {
        GetWorldTimerManager().SetTimer(
            RoarCheckTimer,
            this,
            &AMHMonsterCharacterBase::CheckRoar,
            0.2f,
            true
        );
        UE_LOG(MonsterCharacter, Warning, TEXT("StartRoarCheck | timer started"));
    }
    
}


bool AMHMonsterCharacterBase::CanTriggerRoarToTarget(AActor* Target) const
{
    if (!Target)
    {
        UE_LOG(MonsterCharacter, Warning, TEXT("RoarCheck Fail | Target null"));
        return false;
    }

    const USkeletalMeshComponent* MeshComp = GetMesh();
    if (!MeshComp)
    {
        UE_LOG(MonsterCharacter, Warning, TEXT("RoarCheck Fail | MeshComp null"));
        return false;
    }

    if (!MeshComp->DoesSocketExist(RoarHeadSocketName))
    {
        UE_LOG(MonsterCharacter, Warning, TEXT("RoarCheck Fail | Socket missing: %s"), *RoarHeadSocketName.ToString());
        return false;
    }

    const FVector SocketLocation = MeshComp->GetSocketLocation(RoarHeadSocketName);

    FVector TargetLocation = Target->GetActorLocation();
    if (const ACharacter* TargetCharacter = Cast<ACharacter>(Target))
    {
        if (const UCapsuleComponent* Capsule = TargetCharacter->GetCapsuleComponent())
        {
            TargetLocation.Z += Capsule->GetScaledCapsuleHalfHeight() * 0.8f;
        }
        else
        {
            TargetLocation.Z += RoarTargetHeightOffset;
        }
    }
    else
    {
        TargetLocation.Z += RoarTargetHeightOffset;
    }

    FVector ToTarget = TargetLocation - SocketLocation;
    const float Distance = ToTarget.Size();

    if (Distance > RoarTriggerDistance)
    {
        UE_LOG(MonsterCharacter, Warning, TEXT("RoarCheck Fail | Distance %.2f > %.2f"), Distance, RoarTriggerDistance);
        return false;
    }

    // 너무 가까우면 머리 소켓 기준으로는 각도가 불안정하니 그냥 허용
    if (Distance < 250.f)
    {
        UE_LOG(MonsterCharacter, Warning, TEXT("RoarCheck Debug | Close range auto pass"));
        return true;
    }

    ToTarget.Normalize();

    // 방향은 머리 소켓 회전이 아니라 액터 정면 기준
    const FVector Forward = GetActorForwardVector();
    const FVector Right   = GetActorRightVector();
    const FVector Up      = GetActorUpVector();

    const float ForwardDot = FVector::DotProduct(Forward, ToTarget);
    const float RightDot   = FVector::DotProduct(Right, ToTarget);
    const float UpDot      = FVector::DotProduct(Up, ToTarget);

    if (ForwardDot <= 0.f)
    {
        UE_LOG(MonsterCharacter, Warning, TEXT("RoarCheck Fail | Target behind actor"));
        return false;
    }

    const float YawDeg   = FMath::RadiansToDegrees(FMath::Atan2(RightDot, ForwardDot));
    const float PitchDeg = FMath::RadiansToDegrees(FMath::Atan2(UpDot, ForwardDot));

    UE_LOG(MonsterCharacter, Warning,
        TEXT("RoarCheck Debug | Dist=%.2f Yaw=%.2f Pitch=%.2f | LimitYaw=%.2f LimitPitch=%.2f"),
        Distance, YawDeg, PitchDeg, RoarHorizontalHalfAngleDeg, RoarVerticalHalfAngleDeg);

    if (FMath::Abs(YawDeg) > RoarHorizontalHalfAngleDeg)
    {
        UE_LOG(MonsterCharacter, Warning, TEXT("RoarCheck Fail | Yaw out of range"));
        return false;
    }

    if (FMath::Abs(PitchDeg) > RoarVerticalHalfAngleDeg)
    {
        UE_LOG(MonsterCharacter, Warning, TEXT("RoarCheck Fail | Pitch out of range"));
        return false;
    }

    if (bRoarRequireLineOfSight)
    {
        const FVector TraceStart = SocketLocation + Forward * 20.f;
        const FVector TraceEnd   = TargetLocation;

        FHitResult HitResult;
        FCollisionQueryParams Params(SCENE_QUERY_STAT(RoarLOS), false, this);
        Params.AddIgnoredActor(this);
        Params.AddIgnoredActor(Target); // 타겟 자체는 무시, 장애물만 본다

        FCollisionObjectQueryParams ObjParams;
        ObjParams.AddObjectTypesToQuery(ECC_WorldStatic);
        ObjParams.AddObjectTypesToQuery(ECC_WorldDynamic);

        const bool bBlocked = GetWorld()->LineTraceSingleByObjectType(
            HitResult,
            TraceStart,
            TraceEnd,
            ObjParams,
            Params
        );

        if (bBlocked)
        {
            UE_LOG(MonsterCharacter, Warning,
                TEXT("RoarCheck Fail | LOS blocked by %s"),
                *GetNameSafe(HitResult.GetActor()));
            return false;
        }
    }

    UE_LOG(MonsterCharacter, Warning, TEXT("RoarCheck Success"));
    return true;
}
void AMHMonsterCharacterBase::SetCombatTarget(AActor* NewTarget)
{
    CombatTarget = NewTarget;
}

void AMHMonsterCharacterBase::EnterCombat()
{
    bInCombat = true;
    bRoarCheckEnabled = true;
    StartRoarCheck();
}

void AMHMonsterCharacterBase::ExitCombat()
{
    bInCombat = false;
    CombatTarget = nullptr;
    
    GetWorldTimerManager().ClearTimer(RoarCheckTimer);
}

void AMHMonsterCharacterBase::InitMonsterGAS()
{
    // INIT GAS
    

    if (!bMonsterGASInitialized)
    {
        UE_LOG(MonsterCharacter , Warning , TEXT(": MonsterCharacter Base InitMonsterGAS bMonsterGASInitialized"));

   
    
        if (!AbilitySystemComponent)
        {
            UE_LOG(MonsterCharacter , Warning , TEXT(" : MonsterCharacter Base InitMonsterGAS AbilitySystemComponent"));
            return; 
        }
    
        AbilitySystemComponent->InitAbilityActorInfo(this , this);
    
        ApplyStartupLooseTags();
        GrantStartupAbilities();
        ApplyStartupEffects();
    
        bMonsterGASInitialized = true;
        if (MonsterAttributes)
        {
            UE_LOG(LogTemp, Warning, TEXT("[MonsterGAS] %s HP=%f/%f  Poise=%f/%f  Atk=%f Def=%f"),
                *GetName(),
                MonsterAttributes->GetHealth(), MonsterAttributes->GetMaxHealth(),
                MonsterAttributes->GetPoise(), MonsterAttributes->GetMaxPoise(),
                MonsterAttributes->GetAttackPower(), MonsterAttributes->GetDefense()
            );
        }
        else
        {
            UE_LOG(LogTemp, Error, TEXT("[MonsterGAS] %s MonsterAttributes is NULL"), *GetName());
        }
        
        
    }
}

    void AMHMonsterCharacterBase::ApplyStartupLooseTags()
    {
        UMHMonsterDataAsset* MonsterDataAsset = Cast<UMHMonsterDataAsset>(GASAsset);
        if (!MonsterDataAsset || !AbilitySystemComponent)
        {
            UE_LOG(MonsterCharacter , Warning , TEXT(": MonsterCharacter ApplyStartup "));
            return;
        }
    
        for (const FGameplayTag& Tag : MonsterDataAsset->MonsterTags)
        {
            AbilitySystemComponent->AddLooseGameplayTag(Tag);
        }
    
    
    }

    void AMHMonsterCharacterBase::GrantStartupAbilities()
    {
        UMHMonsterDataAsset* MonsterDataAsset = Cast<UMHMonsterDataAsset>(GASAsset);
        if (!MonsterDataAsset || !AbilitySystemComponent)
        {
            UE_LOG(MonsterCharacter , Warning , TEXT(" : MonsterCharacter GrantStartupAbilities "));

            return;
        }
    
        for (const TSubclassOf<UGameplayAbility>& AbilityClass : MonsterDataAsset->StartupAbilities)
        {
            if (!AbilityClass )
            {
                UE_LOG(MonsterCharacter , Warning , TEXT(" : MonsterCharacter GrantStartupAbilities2 "));
            }
            AbilitySystemComponent->GiveAbility(FGameplayAbilitySpec(AbilityClass, 1, INDEX_NONE, this));
        
        }
    
    }

    void AMHMonsterCharacterBase::ApplyStartupEffects()
    {
        UMHMonsterDataAsset* MonsterDataAsset = Cast<UMHMonsterDataAsset>(GASAsset);
        if (!MonsterDataAsset || !AbilitySystemComponent)
        {
            UE_LOG(MonsterCharacter , Warning , TEXT(" : MonsterCharacter ApplyStartupEffects "));
            return;
        }
    
        for (const TSubclassOf<UGameplayEffect>& EffectClass : MonsterDataAsset->StartupEffects)
        {
            if (!EffectClass ) continue;
        
            FGameplayEffectContextHandle ContextHandle = AbilitySystemComponent->MakeEffectContext();
            ContextHandle.AddSourceObject(this);
        
            FGameplayEffectSpecHandle SpecHandle = AbilitySystemComponent->MakeOutgoingSpec(EffectClass , 1.f , ContextHandle );
        
        
            if (SpecHandle.IsValid())
            {
                UE_LOG(MonsterCharacter , Warning , TEXT(" : MonsterCharacter SpecHandle "));
            
                AbilitySystemComponent->ApplyGameplayEffectSpecToSelf(*SpecHandle.Data.Get());
            
            }
        
        
        }
    }

